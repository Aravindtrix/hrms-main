-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hrms_db
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `candidate_id` int unsigned NOT NULL,
  `offer_date` date DEFAULT NULL,
  `offer_address_line1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer_address_line2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer_address_line3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer_designation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer_joining_date` date DEFAULT NULL,
  `offer_basic` decimal(10,2) DEFAULT NULL,
  `offer_conveyance` decimal(10,2) DEFAULT NULL,
  `offer_medical` decimal(10,2) DEFAULT NULL,
  `offer_special` decimal(10,2) DEFAULT NULL,
  `offer_gross` decimal(10,2) DEFAULT NULL,
  `offer_pf` decimal(10,2) DEFAULT NULL,
  `offer_tds` decimal(10,2) DEFAULT NULL,
  `offer_net` decimal(10,2) DEFAULT NULL,
  `offer_employer_pf` decimal(10,2) DEFAULT NULL,
  `offer_insurance` decimal(10,2) DEFAULT NULL,
  `offer_ctc` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `offer_hra` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_employee_candidate` (`candidate_id`),
  KEY `idx_employee_candidate` (`candidate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,21,'2025-12-16','56','hnf street','Madurai-16','Project heads','2025-12-28',17500.00,1600.00,1250.00,7650.00,35000.00,0.00,0.00,35000.00,0.00,0.00,25000.00,'2025-12-18 07:39:01','2025-12-28 13:22:58',5000.00),(2,24,'2025-12-18','fsfsgfsgfssgf','wtrrretetere',NULL,'Project Heads','2025-12-23',5000.00,1600.00,2000.00,1500.00,30000.00,1000.00,0.00,0.00,0.00,0.00,35000.00,'2025-12-18 11:33:56','2025-12-18 11:33:56',5000.00),(3,28,'2025-12-18','fsfsgfsgfssgf','wtrrretetere',NULL,'Project Heads','2025-12-30',10000.00,4000.00,2000.00,1000.00,1000.00,0.00,0.00,0.00,0.00,0.00,35000.00,'2025-12-18 12:39:09','2025-12-18 12:39:09',1500.00),(4,29,'2025-12-22','fawfa','awdawd','adwa','Project Heads','2025-12-30',45000.00,5000.00,4500.00,4500.00,0.00,0.00,0.00,0.00,0.00,0.00,35000.00,'2025-12-22 17:58:10','2025-12-22 17:58:10',2400.00);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-30  2:16:59
