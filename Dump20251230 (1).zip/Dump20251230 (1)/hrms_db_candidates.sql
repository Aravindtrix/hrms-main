-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hrms_db
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int unsigned DEFAULT NULL,
  `role_key` int DEFAULT NULL,
  `candidate_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience_years` decimal(4,1) DEFAULT NULL,
  `resume_filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resume_blob` longblob,
  `status` enum('applied','shortlisted','interviewed','selected','rejected','hired') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'applied',
  `interviewer` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `hr_marks` decimal(5,2) DEFAULT NULL,
  `head_result` tinyint DEFAULT NULL,
  `head_feedback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `head_notified` tinyint(1) NOT NULL DEFAULT '0',
  `hr_notified` tinyint(1) NOT NULL DEFAULT '0',
  `interviewers` json DEFAULT NULL,
  `head_scores` json DEFAULT NULL,
  `training_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_ticket` (`ticket_id`),
  KEY `idx_role` (`role_key`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidates`
--

LOCK TABLES `candidates` WRITE;
/*!40000 ALTER TABLE `candidates` DISABLE KEYS */;
INSERT INTO `candidates` VALUES (1,1,NULL,'aadith',NULL,NULL,NULL,NULL,NULL,'selected',NULL,'{}','2025-12-16 10:51:43','2025-12-16 12:53:01',NULL,5,'hhssddd',1,1,NULL,NULL,NULL),(3,1,NULL,'hhhh',NULL,NULL,NULL,NULL,NULL,'selected',NULL,'{}','2025-12-16 11:15:34','2025-12-16 12:24:20',NULL,5,'ddfcgcgchcgcc',1,1,NULL,NULL,NULL),(4,1,NULL,'afdafdw',NULL,NULL,NULL,NULL,NULL,'selected',NULL,'{}','2025-12-16 11:19:27','2025-12-17 09:48:00',NULL,3,'Good',1,1,NULL,NULL,NULL),(9,4,3,'ashiq','aadith011003@gmail.com','47282948',5.0,NULL,NULL,'selected',NULL,'{}','2025-12-17 10:21:21','2025-12-17 12:38:53',NULL,4,'excellent',1,1,'[\"Aadith\"]','[{\"label\": \"Technical Skills\", \"score\": 4, \"scope_id\": 1}, {\"label\": \"Problem Solving\", \"score\": 4, \"scope_id\": 4}, {\"label\": \"Communication\", \"score\": 4, \"scope_id\": 7}, {\"label\": \"Team Fit\", \"score\": 4, \"scope_id\": 10}, {\"label\": \"Leadership\", \"score\": 4, \"scope_id\": 13}]',NULL),(11,4,3,'abhi',NULL,NULL,NULL,NULL,NULL,'applied',NULL,'{}','2025-12-17 10:54:29','2025-12-17 12:38:53',NULL,NULL,NULL,0,0,NULL,NULL,NULL),(19,NULL,NULL,'subuu',NULL,NULL,NULL,NULL,NULL,'applied',NULL,'{}','2025-12-17 13:08:00','2025-12-17 13:08:00',NULL,NULL,NULL,0,0,NULL,NULL,NULL),(21,10,3,'Ashiq',NULL,NULL,NULL,NULL,NULL,'hired',NULL,'{}','2025-12-17 13:27:57','2025-12-18 09:54:20',NULL,92,NULL,1,1,'[\"ddd\"]','[{\"label\": \"Technical Skills\", \"score\": 5, \"scope_id\": 2}, {\"label\": \"Problem Solving\", \"score\": 4, \"scope_id\": 5}, {\"label\": \"Communication\", \"score\": 4, \"scope_id\": 8}, {\"label\": \"Team Fit\", \"score\": 5, \"scope_id\": 11}, {\"label\": \"Leadership\", \"score\": 5, \"scope_id\": 14}]','No training needed'),(22,10,3,'subuu',NULL,NULL,NULL,NULL,NULL,'rejected',NULL,'{}','2025-12-17 13:28:07','2025-12-17 13:29:11',NULL,20,'unfit',1,1,'[\"wdwd\"]','[{\"label\": \"Technical Skills\", \"score\": 1, \"scope_id\": 2}, {\"label\": \"Problem Solving\", \"score\": 1, \"scope_id\": 5}, {\"label\": \"Communication\", \"score\": 1, \"scope_id\": 8}, {\"label\": \"Team Fit\", \"score\": 1, \"scope_id\": 11}, {\"label\": \"Leadership\", \"score\": 1, \"scope_id\": 14}]',NULL),(23,10,3,'suii',NULL,NULL,NULL,NULL,NULL,'rejected',NULL,'{}','2025-12-18 06:02:50','2025-12-18 06:03:06',0.00,NULL,NULL,0,0,NULL,NULL,NULL),(28,11,3,'check',NULL,NULL,NULL,NULL,NULL,'hired',NULL,'{}','2025-12-18 12:30:58','2025-12-18 12:41:02',77.00,92,'average',1,1,'[\"checked\"]','[{\"label\": \"Technical Skills\", \"score\": 5, \"scope_id\": 2}, {\"label\": \"Problem Solving\", \"score\": 5, \"scope_id\": 5}, {\"label\": \"Communication\", \"score\": 4, \"scope_id\": 8}, {\"label\": \"Team Fit\", \"score\": 4, \"scope_id\": 11}, {\"label\": \"Leadership\", \"score\": 5, \"scope_id\": 14}]','hgf'),(29,12,3,'sean','awdwnd@gmail.com','098765432',4.0,NULL,NULL,'hired',NULL,'{\"comments\": \"ok\"}','2025-12-22 17:55:20','2025-12-22 17:59:00',77.00,88,'Training needed',1,1,'[\"ray\"]','[{\"label\": \"Technical Skills\", \"score\": 4, \"scope_id\": 2}, {\"label\": \"Problem Solving\", \"score\": 5, \"scope_id\": 5}, {\"label\": \"Communication\", \"score\": 5, \"scope_id\": 8}, {\"label\": \"Team Fit\", \"score\": 4, \"scope_id\": 11}, {\"label\": \"Leadership\", \"score\": 4, \"scope_id\": 14}]','completed');
/*!40000 ALTER TABLE `candidates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-30  2:16:59
